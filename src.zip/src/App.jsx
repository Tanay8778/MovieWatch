import { useEffect, useState } from 'react'
import Search from './components/Search.jsx'
import Spinner from './components/Spinner.jsx'
import MovieCard from './components/MovieCard.jsx'
import MovieDetails from './components/MovieDetails.jsx'
import { useDebounce } from 'react-use'
import { getTrendingMovies, getWatchlistItems, updateSearchCount } from './appwrite.js'

const WatchlistView = ({ onBack }) => {
  const [watchlistMovies, setWatchlistMovies] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [errorMessage, setErrorMessage] = useState('')

  useEffect(() => {
    const loadWatchlist = async () => {
      setIsLoading(true)
      setErrorMessage('')

      try {
        const movies = await getWatchlistItems()
        setWatchlistMovies(movies)
      } catch (error) {
        console.error(error)
        setErrorMessage('Unable to load your watchlist right now.')
      } finally {
        setIsLoading(false)
      }
    }

    loadWatchlist()
  }, [])

  return (
    <section className="watchlist-view">
      <div className="flex items-center justify-between mb-4">
        <h2>Your Watchlist</h2>
        <button type="button" className="watchlist-nav-button" onClick={onBack}>
          Back to Search
        </button>
      </div>

      {isLoading ? (
        <Spinner />
      ) : errorMessage ? (
        <p className="text-red-500">{errorMessage}</p>
      ) : watchlistMovies.length === 0 ? (
        <p>Your watchlist is empty. Add movies from the home page.</p>
      ) : (
        <ul>
          {watchlistMovies.map((movie) => (
            <li key={movie.movieId || movie._id} className="watchlist-item">
              <strong>{movie.title}</strong>
              <span>{movie.movieId}</span>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}

const AppHeader = ({ searchTerm, setSearchTerm, onOpenWatchlist }) => (
  <header>
    <img src="./hero.png" alt="Hero Banner" />
    <h1>Find <span className="text-gradient">Movies</span> You'll Enjoy Without the Hassle</h1>

    <div className="header-actions">
      <Search searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
      <button type="button" className="watchlist-nav-button" onClick={onOpenWatchlist}>
        Open Watchlist
      </button>
    </div>
  </header>
)

const API_BASE_URL = 'https://www.omdbapi.com/';
const API_KEY = import.meta.env.VITE_OMDB_API_KEY;

const App = () => {
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('')
  const [searchTerm, setSearchTerm] = useState('');

  const [movieList, setMovieList] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const [trendingMovies, setTrendingMovies] = useState([]);
  const [selectedMovieId, setSelectedMovieId] = useState(null);
  const [view, setView] = useState('home');

  // Debounce the search term to prevent making too many API requests
  // by waiting for the user to stop typing for 500ms
  useDebounce(() => setDebouncedSearchTerm(searchTerm), 500, [searchTerm])

  const fetchMovies = async (query = '') => {
    setIsLoading(true);
    setErrorMessage('');

    try {
      const endpoint = query
        ? `${API_BASE_URL}?s=${encodeURIComponent(query)}&apikey=${API_KEY}`
        : `${API_BASE_URL}?s=movie&apikey=${API_KEY}`;

      const response = await fetch(endpoint);

      if (!response.ok) {
        throw new Error('Failed to fetch movies');
      }

      const data = await response.json();

      if (data.Response === 'False') {
        setErrorMessage(data.Error || 'Failed to fetch movies');
        setMovieList([]);
        return;
      }

      const movies = data.Search || [];
      setMovieList(movies);

      if (query && movies.length > 0) {
        await updateSearchCount(query, movies[0]);
      }
    } catch (error) {
      console.error(`Error fetching movies: ${error}`);
      setErrorMessage('Error fetching movies. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  }

  const loadTrendingMovies = async () => {
    try {
      const movies = await getTrendingMovies();

      setTrendingMovies(movies);
    } catch (error) {
      console.error(`Error fetching trending movies: ${error}`);
    }
  }

  useEffect(() => {
    fetchMovies(debouncedSearchTerm);
  }, [debouncedSearchTerm]);

  useEffect(() => {
    loadTrendingMovies();
  }, []);

  return (
    <main>
      <div className="pattern"/>

      <div className="wrapper">
        <AppHeader
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          onOpenWatchlist={() => setView('watchlist')}
        />

        {view === 'watchlist' ? (
          <WatchlistView onBack={() => setView('home')} />
        ) : selectedMovieId ? (
          <MovieDetails movieId={selectedMovieId} onBack={() => setSelectedMovieId(null)} />
        ) : (
          <>
            {/* {trendingMovies.length > 0 && (
              <section className="trending">
                <h2>Trending Movies</h2>

                <ul>
                  {trendingMovies.map((movie, index) => (
                    <li key={movie.$id}>
                      <p>{index + 1}</p>
                      <img src={movie.poster_url} alt={movie.title} />
                    </li>
                  ))}
                </ul>
              </section>
            )} */}

            <section className="all-movies">
              <h2>All Movies</h2>

              {isLoading ? (
                <Spinner />
              ) : errorMessage ? (
                <p className="text-red-500">{errorMessage}</p>
              ) : (
                <ul>
                  {movieList.map((movie) => (
                    <MovieCard
                      key={movie.imdbID || movie.Title}
                      movie={movie}
                      onSelect={() => setSelectedMovieId(movie.imdbID)}
                    />
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </div>
    </main>
  )
}

export default App
