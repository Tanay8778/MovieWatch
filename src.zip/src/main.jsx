import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { initAppwriteConnection } from './appwrite.js'

console.log('Initializing Appwrite connection...')
void initAppwriteConnection()

createRoot(document.getElementById('root')).render(<App />)
