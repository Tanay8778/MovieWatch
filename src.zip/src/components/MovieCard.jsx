import { useState } from 'react'
import { handleAddToWatchlist } from '../appwrite.js'

const MovieCard = ({ movie, onSelect }) => {
  const { Title, Poster, Year, Type } = movie
  const [liked, setLiked] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  const posterUrl = Poster && Poster !== 'N/A' ? Poster : '/no-movie.png'
  const year = Year && Year !== 'N/A' ? Year : 'N/A'
  const type = Type && Type !== 'N/A' ? Type : 'movie'

  const handleToggleWatchlist = async () => {
    if (liked || isSaving) {
      return
    }

    setIsSaving(true)
    try {
      await handleAddToWatchlist(movie)
      setLiked(true)
    } catch (error) {
      console.error('Failed to update watchlist:', error)
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="movie-card">
      <button type="button" className="poster-button" onClick={onSelect}>
        <img src={posterUrl} alt={Title} />
      </button>

      <div className="mt-4">
        <h3>{Title}</h3>

        <div className="content">
          <button
            type="button"
            className={`heart-button ${liked ? 'liked' : ''}`}
            onClick={handleToggleWatchlist}
            aria-label={liked ? 'Added to watchlist' : 'Add movie to watchlist'}
            disabled={isSaving}
          >
            {isSaving ? '…' : '♥'}
          </button>

          <button
            type="button"
            className="watchlist-button"
            onClick={handleToggleWatchlist}
            disabled={isSaving}
          >
            {liked ? 'Added' : 'Add to Watchlist'}
          </button>

          <span>•</span>
          <p className="lang">{type}</p>

          <span>•</span>
          <p className="year">{year}</p>
        </div>
      </div>
    </div>
  )
}

export default MovieCard
