import { Account, Client, Databases, ID, Query } from 'appwrite'

const PROJECT_ID = import.meta.env.VITE_APPWRITE_PROJECT_ID
const DATABASE_ID = import.meta.env.VITE_APPWRITE_DATABASE_ID
const COLLECTION_ID = import.meta.env.VITE_APPWRITE_COLLECTION_ID
const APPWRITE_ENDPOINT = import.meta.env.VITE_APPWRITE_ENDPOINT || 'https://cloud.appwrite.io/v1'

const client = new Client()
  .setEndpoint(APPWRITE_ENDPOINT)
  .setProject(PROJECT_ID)

const account = new Account(client)
const database = new Databases(client)

export { account, client, database }

export const initAppwriteConnection = async () => {
  if (!PROJECT_ID || !APPWRITE_ENDPOINT) {
    console.warn('Appwrite project ID or endpoint is missing.')
    return null
  }

  try {
    const session = await account.createAnonymousSession()
    console.log('Appwrite connected with anonymous session.')
    return session
  } catch (error) {
    try {
      const currentUser = await account.get()
      console.log('Appwrite connected:', currentUser?.$id)
      return currentUser
    } catch (fallbackError) {
      console.warn('Appwrite connection pending:', fallbackError)
      return null
    }
  }
}

export const updateSearchCount = async (searchTerm, movie) => {
  if (!DATABASE_ID || !COLLECTION_ID) {
    return
  }

  try {
    const result = await database.listDocuments(DATABASE_ID, COLLECTION_ID, [
      Query.equal('searchTerm', searchTerm),
    ])

    if (result.documents.length > 0) {
      const doc = result.documents[0]

      await database.updateDocument(DATABASE_ID, COLLECTION_ID, doc.$id, {
        count: doc.count + 1,
        title: movie.Title || doc.title,
        movie_id: movie.imdbID || doc.movie_id,
        poster_url: movie.Poster && movie.Poster !== 'N/A' ? movie.Poster : doc.poster_url,
      })
    } else {
      await database.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), {
        searchTerm,
        count: 1,
        title: movie.Title || searchTerm,
        movie_id: movie.imdbID || '',
        poster_url: movie.Poster && movie.Poster !== 'N/A' ? movie.Poster : '',
      })
    }
  } catch (error) {
    console.error(error)
  }
}

export const getTrendingMovies = async () => {
  if (!DATABASE_ID || !COLLECTION_ID) {
    return []
  }

  try {
    const result = await database.listDocuments(DATABASE_ID, COLLECTION_ID, [
      Query.limit(5),
      Query.orderDesc('count'),
    ])

    return result.documents
  } catch (error) {
    console.error(error)
    return []
  }
}

export const getWatchlistItems = async () => {
  try {
    const response = await fetch('http://localhost:5000/api/watchlist', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'x-dev-user': 'demo-user',
      },
    })

    const data = await response.json().catch(() => ({}))

    if (!response.ok) {
      throw new Error(data.error || 'Failed to load watchlist.')
    }

    return data.movies || []
  } catch (error) {
    console.error('Unable to load watchlist.', error)
    throw error
  }
}

export const handleAddToWatchlist = async (movie) => {
  const movieId = movie?.id ?? movie?.imdbID ?? movie?.movieId ?? ''
  const title = movie?.title ?? movie?.Title ?? 'Untitled movie'
  const posterPath = movie?.poster_path ?? movie?.Poster ?? ''

  if (!movieId) {
    throw new Error('Movie ID is required to add it to the watchlist.')
  }

  try {
    let jwt = null

    try {
      const sessionToken = await account.createJWT()
      jwt = sessionToken?.jwt
    } catch {
      jwt = null
    }

    const headers = {
      'Content-Type': 'application/json',
    }

    if (jwt) {
      headers.Authorization = `Bearer ${jwt}`
    } else {
      headers['x-dev-user'] = 'demo-user'
    }

    const response = await fetch('http://localhost:5000/api/watchlist', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        movieId,
        title,
        posterPath,
      }),
    })

    const data = await response.json().catch(() => ({}))

    if (!response.ok) {
      throw new Error(data.error || 'Failed to add movie to the watchlist.')
    }

    return data
  } catch (error) {
    console.error('Unable to add movie to watchlist.', error)
    throw error
  }
}
